package com.vira.wg

import android.content.ComponentName
import android.content.Context
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper

/** Preview pictures shown inside the app, same order as the launcher icons. */
val ICON_PREVIEWS = listOf(R.drawable.icp_0, R.drawable.icp_1, R.drawable.icp_2, R.drawable.icp_3, R.drawable.icp_4)

object AppIcon {
    val NAMES = listOf("پیش‌فرض", "شیشه‌ای", "سه‌بعدی", "موج نئونی", "ستاره‌ای")

    private fun cn(ctx: Context, i: Int) = ComponentName(ctx.packageName, "com.vira.wg.Icon$i")

    /**
     * Each icon is an activity-alias in the manifest. Only one is enabled at a time.
     * The new one is enabled first so the app never disappears from the launcher.
     */
    /** Closes the app a moment after a change so the launcher picks the new icon up. */
    fun closeApp(ctx: Context) {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
        val a = c as? Activity ?: return
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                a.finishAndRemoveTask()
            } catch (e: Exception) {
                a.finishAffinity()
            }
        }, 1400)
    }

    fun set(ctx: Context, idx: Int) {
        try {
            val pm = ctx.packageManager
            pm.setComponentEnabledSetting(
                cn(ctx, idx), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            for (i in NAMES.indices) {
                if (i != idx) {
                    pm.setComponentEnabledSetting(
                        cn(ctx, i), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                    )
                }
            }
        } catch (e: Exception) {
        }
    }
}
