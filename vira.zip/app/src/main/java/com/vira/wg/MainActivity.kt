package com.vira.wg

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        if (Prefs(this).b("secure", true)) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent { App() }
    }

    override fun onResume() {
        super.onResume()
        Game.dndOff(this, Prefs(this))
        Game.brightOff(this, Prefs(this))
    }
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val store = remember { ProfileStore(ctx) }
    val scope = rememberCoroutineScope()

    var look by remember { mutableStateOf(LookStore.load(prefs)) }
    var multi by remember { mutableStateOf(prefs.b("multi", false)) }
    var iconIdx by remember { mutableStateOf(prefs.i("icon", 0).coerceIn(0, AppIcon.NAMES.size - 1)) }
    val theme = remember(look) { makeTheme(look) }
    var tab by remember { mutableStateOf(0) }
    var settings by remember { mutableStateOf(false) }
    var secure by remember { mutableStateOf(prefs.b("secure", true)) }
    var sel by remember { mutableStateOf(prefs.s("sel")) }
    var msg by remember { mutableStateOf<String?>(null) }
    var gamePkgs by remember { mutableStateOf(prefs.s("games").split("\n").filter { it.isNotBlank() }) }
    var pickerOpen by remember { mutableStateOf(false) }
    var pasteOpen by remember { mutableStateOf(false) }
    var pasteText by remember { mutableStateOf("") }
    var pasteName by remember { mutableStateOf("") }
    var qrText by remember { mutableStateOf<String?>(null) }
    var qrName by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Profile?>(null) }
    var editText by remember { mutableStateOf("") }
    var lag by remember { mutableStateOf(prefs.b("lag", false)) }
    var launching by remember { mutableStateOf<GameApp?>(null) }
    var step by remember { mutableStateOf("") }
    val prog = remember { Animatable(0f) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val up by Wg.up.collectAsState()
    val busy by Wg.busy.collectAsState()
    val err by Wg.error.collectAsState()
    val state = if (up) 2 else if (busy) 1 else 0
    val current = store.list.firstOrNull { it.id == sel } ?: store.list.firstOrNull()

    val games by produceState(emptyList<GameApp>(), gamePkgs) {
        value = withContext(Dispatchers.IO) { gamePkgs.mapNotNull { Game.one(ctx, it) } }
    }

    LaunchedEffect(msg) {
        if (msg != null) {
            delay(2600)
            msg = null
        }
    }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        pending = null
        if (r.resultCode == Activity.RESULT_OK) {
            p?.invoke()
        } else {
            msg = "برای اتصال باید اجازه VPN رو بدی"
        }
    }

    fun ensureVpn(then: () -> Unit) {
        val prep = VpnService.prepare(ctx)
        if (prep == null) {
            then()
        } else {
            pending = then
            vpnLauncher.launch(prep)
        }
    }

    fun connectCurrent(): Boolean {
        val c = current ?: return false
        val t = store.config(c.id) ?: return false
        Wg.connect(ctx, Tune.apply(t, prefs.b("lag", false)))
        return true
    }

    fun toggle() {
        if (busy) return
        if (up) {
            Wg.disconnect(ctx)
            return
        }
        if (current == null) {
            msg = "اول یه کانفیگ اضافه کن"
            tab = 2
            return
        }
        ensureVpn { connectCurrent() }
    }

    // ----- import -----
    val report: (Res) -> Unit = { r ->
        if (r.ok > 0 && sel.isBlank()) {
            store.list.firstOrNull()?.let {
                sel = it.id
                prefs.put("sel", it.id)
            }
        }
        msg = if (r.ok > 0) "${r.ok} سرور اضافه شد" + (if (r.bad > 0) " · ${r.bad} نامعتبر" else "")
        else "کانفیگ معتبری پیدا نشد"
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            msg = "در حال وارد کردن…"
            scope.launch { report(withContext(Dispatchers.IO) { Importer.fromUris(ctx, uris, store) }) }
        }
    }
    val scanner = rememberLauncherForActivityResult(ScanContract()) { res ->
        val t = res.contents
        if (t != null) {
            if (Importer.valid(t.removePrefix("\uFEFF"))) {
                qrText = t
                qrName = randomName()
            } else {
                msg = "این QR کانفیگ وایرگارد معتبر نیست"
            }
        }
    }

    // ----- game launch -----
    suspend fun runLaunch(g: GameApp, wantWg: Boolean) {
        launching = g
        prog.snapTo(0f)
        step = "آماده‌سازی"
        prog.animateTo(0.25f, tween(450))
        if (wantWg) {
            step = "اتصال وایرگارد"
            connectCurrent()
            prog.animateTo(0.55f, tween(800))
            var waited = 0
            while (!Wg.up.value && Wg.busy.value && waited < 10000) {
                delay(150)
                waited += 150
            }
            if (!Wg.up.value) {
                step = "وایرگارد وصل نشد؛ بازی بدون اون باز می‌شه"
                delay(1300)
            }
        }
        prog.animateTo(0.7f, tween(300))
        if (prefs.b("gameBright", false) && Game.brightGranted(ctx)) {
            step = "نور صفحه"
            Game.brightOn(ctx, prefs)
        }
        prog.animateTo(0.8f, tween(250))
        if (prefs.b("gameDnd", false) && Game.dndGranted(ctx)) {
            step = "حالت مزاحم نشوید"
            Game.dndOn(ctx, prefs)
        }
        step = "ورود به بازی"
        prog.animateTo(1f, tween(450))
        delay(150)
        launching = null
        Game.open(ctx, g.pkg)
    }

    fun startGame(g: GameApp) {
        if (launching != null) return
        val wantWg = prefs.b("gameWg", true) && current != null && !up
        val go = {
            scope.launch { runLaunch(g, wantWg) }
            Unit
        }
        if (wantWg) ensureVpn(go) else go()
    }

    BackHandler(enabled = launching != null) { }
    BackHandler(enabled = launching == null && (settings || tab != 0)) {
        if (settings) settings = false else tab = 0
    }

    CompositionLocalProvider(LocalVT provides theme, LocalLayoutDirection provides LayoutDirection.Rtl) {
        Bg {
            Crossfade(targetState = if (settings) 3 else tab, animationSpec = tween(180), label = "pg") { p ->
                when (p) {
                    0 -> HomeScreen(
                        state, current?.name, err,
                        onOrb = { toggle() },
                        onServers = { tab = 2 },
                        onSettings = { settings = true },
                        iconIdx = iconIdx
                    )
                    1 -> GamesScreen(
                        games, prefs, current != null,
                        onLaunch = { startGame(it) },
                        onAdd = { pickerOpen = true },
                        onRemove = { g ->
                            gamePkgs = gamePkgs.filter { it != g.pkg }
                            prefs.put("games", gamePkgs.joinToString("\n"))
                        },
                        onMsg = { msg = it }
                    )
                    2 -> ServersScreen(
                        store, current?.id ?: "",
                        onSelect = { id ->
                            sel = id
                            prefs.put("sel", id)
                            if (!up && !busy) tab = 0
                        },
                        onScan = {
                            scanner.launch(
                                ScanOptions()
                                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                    .setPrompt("QR وایرگارد رو جلوی دوربین بگیر")
                                    .setBeepEnabled(false)
                                    .setOrientationLocked(false)
                            )
                        },
                        onFiles = { filePicker.launch(arrayOf("*/*")) },
                        onPaste = { pasteText = ""; pasteName = randomName(); pasteOpen = true },
                        onEdit = { p -> editText = store.config(p.id) ?: ""; editing = p }
                    )
                    else -> SettingsScreen(
                        look, multi, iconIdx, secure, lag,
                        onLook = { look = it; LookStore.save(prefs, it) },
                        onMulti = { on ->
                            multi = on
                            prefs.put("multi", on)
                            if (!on && look.cols.size > 2) {
                                look = Look(look.cols.take(2), look.bg)
                                LookStore.save(prefs, look)
                            }
                        },
                        onIcon = { i ->
                            if (i != iconIdx) {
                                iconIdx = i
                                prefs.put("icon", i)
                                AppIcon.set(ctx, i)
                                msg = "آیکون عوض شد؛ برنامه بسته می‌شه تا تغییر اعمال بشه"
                                AppIcon.closeApp(ctx)
                            }
                        },
                        onReset = {
                            look = LookStore.DEFAULT
                            LookStore.save(prefs, look)
                            multi = false
                            prefs.put("multi", false)
                            val iconChanged = iconIdx != 0
                            iconIdx = 0
                            prefs.put("icon", 0)
                            if (iconChanged) AppIcon.set(ctx, 0)
                            msg = "ظاهر برنامه به حالت پیش‌فرض برگشت"
                            if (iconChanged) AppIcon.closeApp(ctx)
                        },
                        onSecure = { on ->
                            secure = on
                            prefs.put("secure", on)
                            val w = ctx.findActivity()?.window
                            if (on) w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            else w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        },
                        onLag = { lag = it; prefs.put("lag", it) },
                        onBack = { settings = false },
                        onMsg = { msg = it }
                    )
                }
            }

            if (!settings) {
                Dock(
                    tab, { tab = it },
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
                )
            }

            val m = msg
            if (m != null) {
                val shape = RoundedCornerShape(22.dp)
                Box(
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 96.dp)
                        .clip(shape).background(theme.surf).border(1.dp, theme.line, shape)
                        .padding(horizontal = 20.dp, vertical = 11.dp)
                ) { Text(m, color = theme.fg, fontSize = 13.sp) }
            }

            val lg = launching
            if (lg != null) LaunchOverlay(lg, { prog.value }, step)

            if (pickerOpen) {
                GamePicker(
                    gamePkgs,
                    onToggle = { pkg ->
                        gamePkgs = if (pkg in gamePkgs) gamePkgs - pkg else gamePkgs + pkg
                        prefs.put("games", gamePkgs.joinToString("\n"))
                    },
                    onDone = { pickerOpen = false }
                )
            }

            if (pasteOpen) {
                AlertDialog(
                    onDismissRequest = { pasteOpen = false },
                    containerColor = theme.surf, titleContentColor = theme.fg, textContentColor = theme.muted,
                    title = { Text("چسباندن کانفیگ") },
                    text = {
                        Column {
                            SoftField(pasteName, { pasteName = it }, "اسم کانفیگ (هر چی دوست داری)", Modifier.fillMaxWidth())
                            Spacer(Modifier.height(10.dp))
                            SoftField(pasteText, { pasteText = it }, "متن کانفیگ وایرگارد رو اینجا بچسبون", Modifier.fillMaxWidth(), 6)
                        }
                    },
                    confirmButton = {
                        TextButton({
                            val t = pasteText
                            val n = pasteName.trim().ifEmpty { randomName() }
                            pasteOpen = false
                            scope.launch {
                                report(withContext(Dispatchers.IO) { Importer.addTexts(listOf(n to t), store, true) })
                            }
                        }) { Text("افزودن", color = theme.a) }
                    },
                    dismissButton = { TextButton({ pasteOpen = false }) { Text("لغو", color = theme.muted) } }
                )
            }

            val qt = qrText
            if (qt != null) {
                NameDialog(
                    "اسم کانفیگت چی باشه؟", qrName,
                    onOk = { n ->
                        qrText = null
                        scope.launch {
                            report(withContext(Dispatchers.IO) { Importer.addTexts(listOf(n to qt), store, true) })
                        }
                    },
                    onCancel = { qrText = null }
                )
            }

            val ed = editing
            if (ed != null) {
                EditDialog(
                    ed, editText,
                    onSave = { n, t ->
                        store.update(ed.id, n, t)
                        editing = null
                        msg = "ذخیره شد"
                    },
                    onCancel = { editing = null }
                )
            }
        }
    }
}
