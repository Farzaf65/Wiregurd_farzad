package com.vira.wg

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

object Share {
    private const val TEXT = "ویرا؛ اتصال ساده و گیم‌لانچر"

    private fun chooser(ctx: Context, i: Intent, title: String): Boolean = try {
        val c = Intent.createChooser(i, title)
        c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(c)
        true
    } catch (e: Exception) {
        false
    }

    fun link(ctx: Context): Boolean {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, "$TEXT\nدانلود: ${Config.DOWNLOAD_URL}")
        return chooser(ctx, i, "ارسال لینک با")
    }

    /** Copies this app's own APK to the cache and hands it to the system share sheet. */
    fun apk(ctx: Context, done: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            var ok = false
            try {
                val dir = File(app.cacheDir, "share")
                dir.mkdirs()
                val out = File(dir, "Vira.apk")
                File(app.applicationInfo.sourceDir).copyTo(out, overwrite = true)
                val uri = FileProvider.getUriForFile(app, app.packageName + ".fileprovider", out)
                val i = Intent(Intent.ACTION_SEND)
                i.type = "application/vnd.android.package-archive"
                i.putExtra(Intent.EXTRA_STREAM, uri)
                i.putExtra(Intent.EXTRA_TEXT, TEXT)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                ok = true
                Handler(Looper.getMainLooper()).post {
                    done(chooser(app, i, "ارسال فایل برنامه با"))
                }
            } catch (e: Exception) {
                if (!ok) Handler(Looper.getMainLooper()).post { done(false) }
            }
        }.start()
    }
}

/** "Introduce us to your friends": send the download link or the app file itself. */
@Composable
fun SharePage(onBack: () -> Unit, onLink: () -> Unit, onFile: () -> Unit) {
    val v = LocalVT.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            .padding(bottom = 30.dp)
    ) {
        PageHead("معرفی به دوستان", onBack)
        Spacer(Modifier.height(10.dp))
        Hero("share")
        Text(
            "ویرا رو به دوستات معرفی کن", color = v.fg, fontSize = 21.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "هر کدوم راحت‌تره انتخاب کن؛ از تلگرام، بله، ایتا و بقیه‌ی برنامه‌ها می‌شه فرستاد.",
            color = v.muted, fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 21.sp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)
        )
        Spacer(Modifier.height(26.dp))
        var n = 0
        if (Config.DOWNLOAD_URL.isNotBlank()) {
            ContactOption(n++, "send", "ارسال لینک دانلود", "همیشه آخرین نسخه رو می‌ده", onLink)
            Spacer(Modifier.height(12.dp))
        }
        ContactOption(n, "app", "ارسال فایل برنامه", "خود برنامه رو مستقیم بفرست", onFile)
    }
}
