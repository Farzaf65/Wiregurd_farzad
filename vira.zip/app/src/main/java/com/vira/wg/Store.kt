package com.vira.wg

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("vira", Context.MODE_PRIVATE)
    fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun i(k: String, d: Int): Int = sp.getInt(k, d)
    fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun put(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
}

class Profile(val id: String, val name: String)

/**
 * Config texts (with private keys) are stored encrypted. The UI only ever sees the name.
 * If the encrypted store is unavailable on a device, the app-private plain store is used instead.
 */
class ProfileStore(ctx: Context) {
    private val sp: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx.applicationContext, "vira_cfg", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Throwable) {
        ctx.applicationContext.getSharedPreferences("vira_cfg_plain", Context.MODE_PRIVATE)
    }

    var list by mutableStateOf<List<Profile>>(emptyList())
        private set

    init {
        val raw = sp.getString("idx", "") ?: ""
        val l = ArrayList<Profile>()
        for (line in raw.split("\n")) {
            val i = line.indexOf('|')
            if (i > 0) l.add(Profile(line.substring(0, i), line.substring(i + 1)))
        }
        list = l
    }

    private fun idx(l: List<Profile>): String = l.joinToString("\n") { it.id + "|" + it.name }

    fun config(id: String): String? = sp.getString("c_$id", null)

    /** Adds many configs with a single write. Returns how many were added. */
    fun addAll(items: List<Pair<String, String>>): Int {
        val e = sp.edit()
        val names = HashSet<String>()
        for (p in list) names.add(p.name)
        val nl = ArrayList<Profile>(list)
        var n = 0
        for ((nm, text) in items) {
            val base = nm.replace("|", " ").replace("\n", " ").trim().ifEmpty { "سرور" }
            var cand = base
            var k = 2
            while (!names.add(cand)) {
                cand = "$base $k"
                k++
            }
            val id = UUID.randomUUID().toString().replace("-", "").take(10)
            e.putString("c_$id", text)
            nl.add(Profile(id, cand))
            n++
        }
        e.putString("idx", idx(nl))
        e.apply()
        list = nl
        return n
    }

    fun remove(id: String) {
        val nl = list.filter { it.id != id }
        sp.edit().remove("c_$id").putString("idx", idx(nl)).apply()
        list = nl
    }

    fun removeAll() {
        sp.edit().clear().apply()
        list = emptyList()
    }
}
