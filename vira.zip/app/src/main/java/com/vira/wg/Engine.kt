package com.vira.wg

import android.content.Context
import android.os.SystemClock
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayInputStream

object Wg {
    val up = MutableStateFlow(false)
    val busy = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    @Volatile
    var since = 0L

    @Volatile
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "wg0"
        override fun onStateChange(newState: Tunnel.State) {
            up.value = newState == Tunnel.State.UP
        }
    }

    private fun be(ctx: Context): GoBackend {
        var b = backend
        if (b == null) {
            b = GoBackend(ctx.applicationContext)
            backend = b
        }
        return b
    }

    fun connect(ctx: Context, text: String) {
        if (busy.value) return
        busy.value = true
        error.value = null
        Thread {
            try {
                val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
                be(ctx).setState(tunnel, Tunnel.State.UP, cfg)
                since = SystemClock.elapsedRealtime()
                up.value = true
            } catch (e: Exception) {
                up.value = false
                error.value = "اتصال برقرار نشد. اینترنت یا کانفیگ رو چک کن."
            } finally {
                busy.value = false
            }
        }.start()
    }

    fun disconnect(ctx: Context) {
        if (backend == null) {
            up.value = false
            return
        }
        busy.value = true
        Thread {
            try {
                be(ctx).setState(tunnel, Tunnel.State.DOWN, null)
            } catch (e: Exception) {
            }
            up.value = false
            busy.value = false
        }.start()
    }
}
