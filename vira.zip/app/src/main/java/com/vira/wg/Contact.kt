package com.vira.wg

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

object Reach {
    const val SUPPORT = "FARZAD_KM12345"
    const val CHANNEL = "last_circle_king"
    const val MAIL = "farzad.km15@gmail.com"

    /** The waiting time on screen is only a visual effect. */
    fun waitMs(): Long = (1000..9000).random().toLong()

    private fun start(ctx: Context, i: Intent, title: String): Boolean = try {
        val c = Intent.createChooser(i, title)
        c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(c)
        true
    } catch (e: Exception) {
        false
    }

    fun telegram(ctx: Context, id: String): Boolean =
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$id")), "باز کردن با")

    fun mail(ctx: Context): Boolean {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(MAIL))
        i.putExtra(Intent.EXTRA_SUBJECT, "درخواست پشتیبانی ویرا")
        return start(ctx, i, "انتخاب برنامه ایمیل")
    }
}

/** Opening page of "Contact us": a calm hero and three cards. */
@Composable
fun ContactHome(onBack: () -> Unit, onSupport: () -> Unit, onChannel: () -> Unit, onMail: () -> Unit) {
    val v = LocalVT.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            .padding(bottom = 30.dp)
    ) {
        PageHead("ارتباط با ما", onBack)
        Spacer(Modifier.height(10.dp))
        Hero("chat")
        Text(
            "ما کنارتیم", color = v.fg, fontSize = 21.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "از هر راهی که برات راحت‌تره با ما در ارتباط باش.", color = v.muted, fontSize = 13.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(26.dp))
        ContactOption(0, "chat", "پشتیبانی تلگرام", "گفتگوی مستقیم با پشتیبان", onSupport)
        Spacer(Modifier.height(12.dp))
        ContactOption(1, "wave", "کانال تلگرام", "اخبار و اطلاعیه‌های ویرا", onChannel)
        Spacer(Modifier.height(12.dp))
        ContactOption(2, "mail", "ایمیل پشتیبانی", "ارسال توضیحات و تصویر", onMail)
        Spacer(Modifier.height(20.dp))
        Text(
            "اگه مشکلی پیش اومد، یه اسکرین‌شات از مشکل بفرست تا سریع‌تر بررسی بشه. پیام‌ها حتماً خونده می‌شن.",
            color = v.muted, fontSize = 12.sp, lineHeight = 19.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)
        )
    }
}

/** Separate page for e-mail. */
@Composable
fun EmailPage(onBack: () -> Unit, onSend: () -> Unit) {
    val v = LocalVT.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            .padding(bottom = 30.dp)
    ) {
        PageHead("ایمیل پشتیبانی", onBack)
        Spacer(Modifier.height(10.dp))
        Hero("mail")
        Text(
            "ارتباط با پشتیبانی از طریق ایمیل", color = v.fg, fontSize = 19.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().panel().padding(18.dp)) {
            Text(
                "برای بررسی بهتر درخواست شما، لطفاً توضیحات خود را به‌همراه تصاویر مرتبط ارسال کنید تا کارشناسان بتوانند موضوع را دقیق‌تر بررسی کنند.",
                color = v.fg, fontSize = 14.sp, lineHeight = 25.sp
            )
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.07f)))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("آدرس پشتیبانی", color = v.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("‎" + Reach.MAIL, color = v.fg, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(22.dp))
        val shape = RoundedCornerShape(26.dp)
        val src = remember { MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val sc by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "btn")
        Row(
            Modifier.fillMaxWidth().graphicsLayer { scaleX = sc; scaleY = sc }.clip(shape).background(v.fg)
                .clickable(src, null) { onSend() }.padding(vertical = 16.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ico("mail", v.bg, 20.dp)
            Spacer(Modifier.width(10.dp))
            Text("ارسال ایمیل به پشتیبانی", color = v.bg, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "ضمیمه کردن تصویر و فایل از داخل برنامه ایمیل انجام می‌شه.",
            color = v.muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun Hero(icon: String) {
    val v = LocalVT.current
    val t = rememberInfiniteTransition(label = "hero")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Box(Modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(170.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            for (k in 0..1) {
                val ph = (p + k * 0.5f) % 1f
                drawCircle(v.a.copy(alpha = (1f - ph) * 0.22f), 44.dp.toPx() + 36.dp.toPx() * ph, c, style = Stroke(1.5.dp.toPx()))
            }
            drawCircle(Color.White.copy(alpha = 0.04f), 52.dp.toPx(), c)
        }
        Box(
            Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                .border(1.dp, Color.White.copy(alpha = 0.16f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Ico(icon, v.fg, 32.dp) }
    }
}

@Composable
private fun ContactOption(index: Int, icon: String, title: String, sub: String, onClick: () -> Unit) {
    val v = LocalVT.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(120L + index * 90L)
        shown = true
    }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(420), label = "in")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, tween(130), label = "press")
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth()
            .graphicsLayer { alpha = a; translationY = (1f - a) * 40f; scaleX = sc; scaleY = sc }
            .clip(shape)
            .background(Color.White.copy(alpha = if (pressed) 0.12f else 0.06f))
            .border(1.dp, Color.White.copy(alpha = if (pressed) 0.22f else 0.1f), shape)
            .clickable(src, null) { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.07f)),
            contentAlignment = Alignment.Center
        ) { Ico(icon, v.a, 26.dp) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = v.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = v.muted, fontSize = 12.5.sp)
        }
        Ico("chev", v.muted, 18.dp)
    }
}

/**
 * Floating card for the "connecting" step. [onDismiss] is null when it can't be closed.
 * The animation does not show any remaining time.
 */
@Composable
fun ConnectDialog(icon: String, title: String, sub: String?, onDismiss: (() -> Unit)?) {
    val v = LocalVT.current
    Dialog(
        onDismissRequest = { onDismiss?.invoke() },
        properties = DialogProperties(
            dismissOnBackPress = onDismiss != null,
            dismissOnClickOutside = onDismiss != null,
            usePlatformDefaultWidth = false
        )
    ) {
        val shape = RoundedCornerShape(30.dp)
        Column(
            Modifier.padding(horizontal = 40.dp).fillMaxWidth().clip(shape).background(v.surf)
                .border(1.dp, Color.White.copy(alpha = 0.12f), shape).padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ConnectAnim(icon)
            Spacer(Modifier.height(18.dp))
            Text(title, color = v.fg, fontSize = 15.5.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            if (sub != null) {
                Spacer(Modifier.height(6.dp))
                Text(sub, color = v.muted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun ConnectAnim(icon: String) {
    val v = LocalVT.current
    val t = rememberInfiniteTransition(label = "conn")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Box(Modifier.size(120.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(120.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            for (k in 0..2) {
                val ph = (p + k / 3f) % 1f
                drawCircle(v.a.copy(alpha = (1f - ph) * 0.35f), 32.dp.toPx() + 26.dp.toPx() * ph, c, style = Stroke(1.5.dp.toPx()))
            }
            val r = 40.dp.toPx()
            drawArc(
                v.a, p * 360f, 80f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        Box(
            Modifier.size(58.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) { Ico(icon, v.fg, 26.dp) }
    }
}
