package com.vira.wg

/** Values you fill in once. Blank means the related feature is hidden. */
object Config {
    /** Permanent download link of the newest APK (for example a GitHub Releases "latest" link). */
    const val DOWNLOAD_URL = ""

    /** Web OAuth client id from Google Cloud (used for "Sign in with Google"). */
    const val GOOGLE_CLIENT_ID = "676339687076-r2onp199ma0ie9132tb8r5u289svofv0.apps.googleusercontent.com"
}
