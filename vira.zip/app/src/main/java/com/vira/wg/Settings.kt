package com.vira.wg

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Menu ----------
// Calm and neutral: grey glass panels, one short list. Color only appears where you actually pick colors.

private val TABS = listOf("رنگ اصلی", "پس‌زمینه", "گیمینگ", "دخترانه", "پسرانه", "پیش‌فرض", "ترکیب‌ها")

@Composable
fun SettingsScreen(
    look: Look,
    multi: Boolean,
    iconIdx: Int,
    secure: Boolean,
    lag: Boolean,
    saver: Boolean,
    acct: Acct?,
    onLook: (Look) -> Unit,
    onMulti: (Boolean) -> Unit,
    onIcon: (Int) -> Unit,
    onReset: () -> Unit,
    onSecure: (Boolean) -> Unit,
    onLag: (Boolean) -> Unit,
    onSaver: (Boolean) -> Unit,
    onSignIn: () -> Unit,
    onSignOut: () -> Unit,
    onBack: () -> Unit,
    onMsg: (String) -> Unit
) {
    val v = LocalVT.current
    val ctx = LocalContext.current
    var page by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf(0) }
    BackHandler(enabled = page != 0) { page = if (page == 4) 3 else 0 }

    // "Contact us": which connecting step is on screen (0 none, 1 support, 2 channel, 3 e-mail).
    var link by remember { mutableStateOf(0) }
    LaunchedEffect(link) {
        if (link != 0) {
            delay(Reach.waitMs())
            val ok = when (link) {
                1 -> Reach.telegram(ctx, Reach.SUPPORT)
                2 -> Reach.telegram(ctx, Reach.CHANNEL)
                else -> Reach.mail(ctx)
            }
            link = 0
            if (!ok) onMsg("برنامه‌ای برای باز کردن پیدا نشد")
        }
    }
    fun go(k: Int) {
        if (link == 0) link = k
    }

    // Normal mode: one tap sets the look. Multi mode: every tap adds or removes one solid color.
    fun pickSolid(a: Long) {
        if (multi) {
            val c = look.cols
            if (a in c) {
                if (c.size > 1) onLook(Look(c - a, look.bg)) else onMsg("حداقل یک رنگ باید انتخاب باشه")
            } else if (c.size >= 5) {
                onMsg("حداکثر ۵ رنگ می‌تونی انتخاب کنی")
            } else onLook(Look(c + a, look.bg))
        } else onLook(Look(listOf(a), look.bg))
    }

    fun pickPair(p: Pair<Long, Long>) {
        if (multi) pickSolid(p.first) else onLook(Look(listOf(p.first, p.second), look.bg))
    }

    fun solidOn(a: Long) = if (multi) a in look.cols else look.cols == listOf(a)
    fun pairOn(p: Pair<Long, Long>) = if (multi) p.first in look.cols else look.cols == listOf(p.first, p.second)

    val swc = SwitchDefaults.colors(
        checkedThumbColor = v.bg, checkedTrackColor = v.a,
        uncheckedThumbColor = v.muted, uncheckedTrackColor = v.surf, uncheckedBorderColor = v.line
    )

    Box(Modifier.fillMaxSize().background(v.bg)) {
        Crossfade(page, animationSpec = tween(220), label = "page") { p ->
            when (p) {
                1 -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
                    PageHead("رنگ‌ها") { page = 0 }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().panel().padding(16.dp)) {
                        Box(
                            Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                                .background(Brush.horizontalGradient(v.mix))
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("انتخاب چند رنگ مختلف", color = v.fg, fontSize = 14.5.sp)
                                Text(
                                    if (multi) "${look.cols.size} از ۵ رنگ انتخاب شده" else "تا ۵ رنگ، بدون نیاز به تأیید",
                                    color = v.muted, fontSize = 12.sp
                                )
                            }
                            Switch(multi, onMulti, colors = swc)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (i in TABS.indices) {
                            val on = i == tab
                            Text(
                                TABS[i], color = if (on) v.fg else v.muted, fontSize = 13.sp,
                                fontWeight = if (on) FontWeight.Medium else FontWeight.Normal, maxLines = 1,
                                modifier = Modifier.clip(RoundedCornerShape(16.dp))
                                    .background(if (on) Color.White.copy(alpha = 0.12f) else Color.Transparent)
                                    .clickable { tab = i }.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Crossfade(tab, animationSpec = tween(200), label = "tab") { t ->
                            Column(Modifier.fillMaxWidth().panel().padding(16.dp)) {
                                when (t) {
                                    0 -> {
                                        Grid(SOLIDS.size) { i -> Swatch(SOLIDS[i], null, solidOn(SOLIDS[i])) { pickSolid(SOLIDS[i]) } }
                                        Caption("رنگ دکمه‌ها و جزئیات")
                                    }
                                    1 -> {
                                        Grid(BGS.size + 1) { i ->
                                            if (i == 0) Swatch(look.cols.first(), null, look.bg == -1, auto = true) { onLook(Look(look.cols, -1)) }
                                            else BgSwatch(BGS[i - 1].c, look.bg == i - 1) { onLook(Look(look.cols, i - 1)) }
                                        }
                                        Caption(
                                            (if (look.bg in BGS.indices) BGS[look.bg].name else "خودکار") +
                                                " · دایره‌ی اول: هم‌رنگ رنگ اصلی"
                                        )
                                    }
                                    2 -> {
                                        PairGrid(GAMING, multi, ::pairOn, ::pickPair)
                                        Caption("نئونی و پرانرژی")
                                    }
                                    3 -> {
                                        PairGrid(GIRLS, multi, ::pairOn, ::pickPair)
                                        Caption("ملایم و پاستلی")
                                    }
                                    4 -> {
                                        PairGrid(BOYS, multi, ::pairOn, ::pickPair)
                                        Caption("آبی، سبز و فولادی")
                                    }
                                    5 -> {
                                        PairGrid(PALS.map { it.a to it.b }, multi, ::pairOn, ::pickPair)
                                        Caption("${PALS.size} رنگ آماده")
                                    }
                                    else -> {
                                        for (r in GRADS.chunked(2)) {
                                            Row(
                                                Modifier.padding(bottom = 10.dp),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                for (g in r) {
                                                    val on = look.cols == listOf(g.c1, g.c2, g.c3)
                                                    GradCard(g, on, Modifier.weight(1f)) {
                                                        onLook(Look(listOf(g.c1, g.c2, g.c3), look.bg))
                                                    }
                                                }
                                                if (r.size == 1) Spacer(Modifier.weight(1f))
                                            }
                                        }
                                        Caption("ترکیب سه‌رنگ؛ تو کل برنامه اعمال می‌شه")
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(30.dp))
                    }
                }

                2 -> Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
                    PageHead("آیکون برنامه") { page = 0 }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().panel().padding(16.dp)) {
                        for (r in AppIcon.NAMES.indices.chunked(3)) {
                            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                for (i in r) IconTile(i, i == iconIdx) { onIcon(i) }
                                for (k in r.size until 3) Spacer(Modifier.width(84.dp))
                            }
                        }
                        Caption("با انتخاب آیکون، تغییر خودکار اعمال می‌شه و برنامه بسته می‌شه. دوباره بازش کن.")
                    }
                }

                3 -> ContactHome(
                    onBack = { page = 0 },
                    onSupport = { go(1) },
                    onChannel = { go(2) },
                    onMail = { page = 4 }
                )

                4 -> EmailPage(onBack = { page = 3 }, onSend = { go(3) })

                5 -> SharePage(
                    onBack = { page = 0 },
                    onLink = { if (!Share.link(ctx)) onMsg("برنامه‌ای برای ارسال پیدا نشد") },
                    onFile = {
                        onMsg("در حال آماده‌سازی فایل...")
                        Share.apk(ctx) { ok -> if (!ok) onMsg("ارسال فایل انجام نشد") }
                    }
                )

                else -> Column(
                    Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp).padding(bottom = 30.dp)
                ) {
                    PageHead("منو") { onBack() }
                    Spacer(Modifier.height(16.dp))
                    if (Account.enabled()) {
                        Column(Modifier.fillMaxWidth().panel()) {
                            if (acct == null) {
                                NavRow("user", "ورود با حساب گوگل", chev = false) { onSignIn() }
                            } else {
                                NavRow(
                                    "user", acct.name.ifBlank { "حساب گوگل" }, "\u200E" + acct.email, chev = false
                                ) { }
                                Divider()
                                NavRow("back", "خروج از حساب", chev = false) { onSignOut() }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                    }
                    Column(Modifier.fillMaxWidth().panel()) {
                        NavRow("palette", "رنگ‌ها و تم", trailing = {
                            Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                                for (c in look.cols) {
                                    Box(Modifier.size(16.dp).clip(CircleShape).background(Color(c)).border(1.5.dp, v.bg, CircleShape))
                                }
                            }
                        }) { page = 1 }
                        Divider()
                        NavRow("app", "آیکون برنامه", AppIcon.NAMES[iconIdx.coerceIn(0, AppIcon.NAMES.size - 1)]) { page = 2 }
                    }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().panel()) {
                        SwitchRow("مخفی‌سازی صفحه", "جلوی اسکرین‌شات و نمایش تو لیست برنامه‌های اخیر", secure, onSecure, swc)
                        Divider()
                        SwitchRow("حالت کاهش لگ", "MTU کوچک‌تر و Keepalive ثابت؛ تأثیرش به اپراتور بستگی داره", lag, onLag, swc)
                        Divider()
                        SwitchRow("حالت صرفه‌جویی", "انیمیشن‌های تزئینی ثابت می‌شن تا باتری و پردازنده کمتر درگیر بشه. با صرفه‌جویی خود گوشی هم خودکار فعال می‌شه", saver, onSaver, swc)
                    }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().panel()) {
                        NavRow("chat", "ارتباط با ما") { page = 3 }
                    }
                    Spacer(Modifier.height(22.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(16.dp)).clickable { onReset() }.padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Ico("reset", v.muted, 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("بازگشت به تنظیمات پیش‌فرض", color = v.muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("ویرا · نسخه 1.0", color = v.muted.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
        if (link != 0) {
            val (ic, t) = when (link) {
                1 -> "chat" to "در حال برقراری ارتباط با پشتیبانی..."
                2 -> "wave" to "در حال آماده‌سازی ورود به کانال تلگرام..."
                else -> "mail" to "در حال اتصال به Gmail..."
            }
            ConnectDialog(ic, t, "برای لغو، بیرون از پنجره بزن", onDismiss = { link = 0 })
        }
    }
}

/** Neutral glass panel: light grey, thin edge, no accent color. */
@Composable
fun Modifier.panel(r: androidx.compose.ui.unit.Dp = 24.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.075f), Color.White.copy(alpha = 0.035f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))), s)
}

@Composable
fun PageHead(title: String, onBack: () -> Unit) {
    val v = LocalVT.current
    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.07f)).clickable { onBack() },
            contentAlignment = Alignment.Center
        ) { Ico("back", v.fg, 20.dp) }
        Spacer(Modifier.width(14.dp))
        Text(title, color = v.fg, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Divider() {
    Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.06f)))
}

@Composable
private fun Caption(text: String) {
    val v = LocalVT.current
    Spacer(Modifier.height(12.dp))
    Text(text, color = v.muted, fontSize = 11.5.sp, lineHeight = 17.sp)
}

/** One list row: quiet icon, title, small value, and an arrow when it opens another page. */
@Composable
private fun NavRow(
    icon: String,
    title: String,
    value: String? = null,
    chev: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    val v = LocalVT.current
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ico(icon, v.muted, 20.dp)
        Spacer(Modifier.width(14.dp))
        Text(title, color = v.fg, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = v.muted, fontSize = 13.sp, maxLines = 1)
        if (trailing != null) trailing()
        if (chev) {
            Spacer(Modifier.width(6.dp))
            Ico("back", v.muted, 18.dp)
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String,
    on: Boolean,
    onChange: (Boolean) -> Unit,
    colors: androidx.compose.material3.SwitchColors
) {
    val v = LocalVT.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = v.fg, fontSize = 15.sp)
            Text(sub, color = v.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Switch(on, onChange, colors = colors)
    }
}

/** Five circles per row, same size and spacing everywhere. */
@Composable
private fun Grid(count: Int, item: @Composable (Int) -> Unit) {
    val rows = (count + 4) / 5
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (c in 0 until 5) {
                    val i = r * 5 + c
                    if (i < count) item(i) else Spacer(Modifier.size(48.dp))
                }
            }
        }
    }
}

/** Pairs show as gradient circles. In multi mode they show as plain single-color circles. */
@Composable
private fun PairGrid(
    list: List<Pair<Long, Long>>,
    multi: Boolean,
    isOn: (Pair<Long, Long>) -> Boolean,
    onPick: (Pair<Long, Long>) -> Unit
) {
    val items = if (multi) list.distinctBy { it.first } else list
    Grid(items.size) { i ->
        val p = items[i]
        Swatch(p.first, if (multi) null else p.second, isOn(p)) { onPick(p) }
    }
}

@Composable
private fun Swatch(a: Long, b: Long?, on: Boolean, auto: Boolean = false, onClick: () -> Unit) {
    val v = LocalVT.current
    val sc by animateFloatAsState(if (on) 1.08f else 1f, tween(200), label = "sc")
    val fill: Brush = when {
        auto -> Brush.linearGradient(listOf(v.bg, Color(a)))
        b != null -> Brush.linearGradient(listOf(Color(a), Color(b)))
        else -> SolidColor(Color(a))
    }
    Box(
        Modifier.size(48.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(CircleShape).background(fill)
            .border(if (on) 3.dp else 1.dp, if (on) v.fg else Color.White.copy(alpha = 0.14f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (on) Ico("check", Color(0xFF0A0F1C), 22.dp)
        else if (auto) Text("A", color = v.fg, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BgSwatch(c: Long, on: Boolean, onClick: () -> Unit) {
    val v = LocalVT.current
    val sc by animateFloatAsState(if (on) 1.08f else 1f, tween(200), label = "bsc")
    val base = Color(c)
    Box(
        Modifier.size(48.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(CircleShape)
            .background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.lerp(base, Color.White, 0.22f), base)))
            .border(if (on) 3.dp else 1.5.dp, if (on) v.fg else Color.White.copy(alpha = 0.30f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { if (on) Ico("check", v.fg, 22.dp) }
}

@Composable
private fun GradCard(g: Grad, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val v = LocalVT.current
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(Color.White.copy(alpha = 0.05f))
            .border(if (on) 2.dp else 1.dp, if (on) v.fg else Color.White.copy(alpha = 0.12f), shape)
            .clickable { onClick() }.padding(10.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(12.dp))
                .background(Brush.horizontalGradient(listOf(Color(g.c1), Color(g.c2), Color(g.c3)))),
            contentAlignment = Alignment.Center
        ) { if (on) Ico("check", Color(0xFF0A0F1C), 22.dp) }
        Spacer(Modifier.height(8.dp))
        Text(g.name, color = v.fg, fontSize = 12.5.sp, maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun IconTile(i: Int, on: Boolean, onClick: () -> Unit) {
    val v = LocalVT.current
    val shape = RoundedCornerShape(22.dp)
    val sc by animateFloatAsState(if (on) 1.04f else 1f, tween(200), label = "isc")
    Column(
        Modifier.width(84.dp).clip(RoundedCornerShape(24.dp)).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(76.dp).graphicsLayer { scaleX = sc; scaleY = sc }) {
            Image(
                painterResource(ICON_PREVIEWS[i]), null,
                Modifier.fillMaxSize().clip(shape)
                    .border(if (on) 3.dp else 1.dp, if (on) v.a else Color.White.copy(alpha = 0.14f), shape)
            )
            if (on) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp).size(24.dp).clip(CircleShape)
                        .background(v.a),
                    contentAlignment = Alignment.Center
                ) { Ico("check", v.bg, 15.dp) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(AppIcon.NAMES[i], color = if (on) v.fg else v.muted, fontSize = 11.5.sp, maxLines = 1)
    }
}
