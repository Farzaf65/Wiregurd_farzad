package com.vira.wg

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

class GameApp(val pkg: String, val label: String, val icon: ImageBitmap?, val known: Boolean)

object Game {
    val KNOWN = setOf(
        "com.tencent.ig", "com.pubg.imobile", "com.vng.pubgmobile", "com.rekoo.pubgm",
        "com.pubg.krmobile", "com.tencent.tmgp.pubgmhd", "com.activision.callofduty.shooter",
        "com.dts.freefireth", "com.dts.freefiremax", "com.supercell.clashofclans",
        "com.supercell.brawlstars", "com.supercell.clashroyale", "com.mobile.legends",
        "com.miHoYo.GenshinImpact", "com.innersloth.spacemafia", "com.mojang.minecraftpe",
        "com.roblox.client", "com.gameloft.android.ANMP.GloftA9HM", "com.epicgames.fortnite"
    )

    /** All apps that have a launcher icon (except this app), known games first. */
    fun loadAll(ctx: Context): List<GameApp> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<GameApp>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(i, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            try {
                val label = ri.loadLabel(pm).toString()
                val ic = ri.loadIcon(pm).toBitmap(80, 80).asImageBitmap()
                out.add(GameApp(pkg, label, ic, pkg in KNOWN))
            } catch (e: Exception) {
            }
        }
        return out.sortedWith(compareByDescending<GameApp> { it.known }.thenBy { it.label.lowercase() })
    }

    fun one(ctx: Context, pkg: String): GameApp? = try {
        val pm = ctx.packageManager
        val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        GameApp(pkg, label, pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap(), pkg in KNOWN)
    } catch (e: Exception) {
        null
    }

    fun open(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    /** Opens the system page of the app, where the user can clear its cache by hand. */
    fun appInfo(ctx: Context, pkg: String) {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    fun dndGranted(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true

    fun dndSettings(ctx: Context) {
        try {
            val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    fun dndOn(ctx: Context, p: Prefs) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (!nm.isNotificationPolicyAccessGranted) return
        if (!p.b("dndActive", false)) p.put("dndPrev", nm.currentInterruptionFilter)
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        p.put("dndActive", true)
    }

    /** Called when the user comes back to the app. */
    fun dndOff(ctx: Context, p: Prefs) {
        if (!p.b("dndActive", false)) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(p.i("dndPrev", NotificationManager.INTERRUPTION_FILTER_ALL))
        }
        p.put("dndActive", false)
    }
}
