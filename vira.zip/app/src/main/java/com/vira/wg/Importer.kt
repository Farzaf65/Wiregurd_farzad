package com.vira.wg

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.wireguard.config.Config
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

class Res(val ok: Int, val bad: Int)

object Importer {
    private val split = Regex("(?=\\[Interface\\])", RegexOption.IGNORE_CASE)

    fun valid(t: String): Boolean = try {
        Config.parse(ByteArrayInputStream(t.toByteArray()))
        true
    } catch (e: Exception) {
        false
    }

    private fun readCap(i: InputStream, cap: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            total += n
            if (total > cap) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun baseName(path: String): String {
        val f = path.substringAfterLast('/').substringAfterLast('\\')
        return if (f.contains('.')) f.substringBeforeLast('.') else f
    }

    private fun displayName(ctx: Context, u: Uri): String {
        try {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return "config"
    }

    private fun isZip(ctx: Context, u: Uri): Boolean = try {
        ctx.contentResolver.openInputStream(u)?.use {
            val b = ByteArray(4)
            val n = it.read(b)
            n == 4 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()
        } ?: false
    } catch (e: Exception) {
        false
    }

    /** Validates every text (a text may hold several configs) and stores the good ones in one write. */
    fun addTexts(items: List<Pair<String, String>>, store: ProfileStore): Res {
        val good = ArrayList<Pair<String, String>>()
        var bad = 0
        for ((name, raw) in items) {
            val text = raw.removePrefix("﻿")
            val parts = text.split(split).filter { it.contains("[interface]", ignoreCase = true) }
            if (parts.isEmpty()) {
                bad++
                continue
            }
            for ((i, p) in parts.withIndex()) {
                if (valid(p)) good.add((if (parts.size > 1) "$name ${i + 1}" else name) to p.trim()) else bad++
            }
        }
        val n = if (good.isEmpty()) 0 else store.addAll(good)
        return Res(n, bad)
    }

    /** Files can be single .conf files or .zip archives with any number of .conf files (also inside folders). */
    fun fromUris(ctx: Context, uris: List<Uri>, store: ProfileStore): Res {
        val items = ArrayList<Pair<String, String>>()
        var bad = 0
        for (u in uris) {
            try {
                if (isZip(ctx, u)) {
                    val input = ctx.contentResolver.openInputStream(u) ?: continue
                    ZipInputStream(BufferedInputStream(input)).use { z ->
                        var e = z.nextEntry
                        var count = 0
                        while (e != null && count < 5000) {
                            val nm = e.name
                            if (!e.isDirectory && nm.lowercase().endsWith(".conf") && !nm.contains("__MACOSX")) {
                                val b = readCap(z, 128 * 1024)
                                if (b == null) {
                                    bad++
                                } else {
                                    items.add(baseName(nm) to String(b, Charsets.UTF_8))
                                    count++
                                }
                            }
                            e = z.nextEntry
                        }
                    }
                } else {
                    val b = ctx.contentResolver.openInputStream(u)?.use { readCap(it, 256 * 1024) }
                    if (b == null) bad++ else items.add(baseName(displayName(ctx, u)) to String(b, Charsets.UTF_8))
                }
            } catch (e: Exception) {
                bad++
            }
        }
        val r = addTexts(items, store)
        return Res(r.ok, r.bad + bad)
    }
}
