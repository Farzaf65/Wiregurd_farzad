package com.vira.wg

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

// ---------- Home ----------

@Composable
fun HomeScreen(
    state: Int,
    name: String?,
    error: String?,
    onOrb: () -> Unit,
    onServers: () -> Unit,
    onSettings: () -> Unit
) {
    val v = LocalVT.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ویرا", color = v.fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(v.surf).clickable { onSettings() },
                contentAlignment = Alignment.Center
            ) { Ico("sliders", v.fg) }
        }
        Spacer(Modifier.weight(1f))
        Orb(state, onOrb)
        Spacer(Modifier.height(6.dp))
        if (state == 2) {
            Text(
                "متصل",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(v.a, v.b)),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Timer()
        } else {
            Text(
                if (state == 1) "در حال اتصال…" else "آماده اتصال",
                color = v.fg, fontSize = 24.sp, fontWeight = FontWeight.Bold
            )
            Text(
                if (name == null) "اول یه کانفیگ اضافه کن" else "برای شروع دکمه رو لمس کن",
                color = v.muted, fontSize = 13.sp
            )
        }
        if (error != null && state == 0) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = v.b, fontSize = 12.5.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(22.dp))
        val shape = RoundedCornerShape(26.dp)
        Row(
            Modifier.clip(shape).background(v.surf).border(1.dp, v.line, shape)
                .clickable { onServers() }.padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ico(if (name == null) "plus" else "srv", v.a, 20.dp)
            Spacer(Modifier.width(10.dp))
            Text(name ?: "افزودن کانفیگ", color = v.fg, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (name != null) {
                Spacer(Modifier.width(10.dp))
                Text("••••••", color = v.muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.weight(1.4f))
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
private fun Timer() {
    val v = LocalVT.current
    val secs by produceState(0L) {
        while (true) {
            value = (SystemClock.elapsedRealtime() - Wg.since) / 1000
            delay(1000)
        }
    }
    Text(
        String.format(Locale.US, "%02d:%02d:%02d", secs / 3600, secs % 3600 / 60, secs % 60),
        color = v.muted, fontSize = 15.sp, letterSpacing = 1.sp
    )
}

// ---------- Dock ----------

@Composable
fun Dock(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val v = LocalVT.current
    val items = listOf("home" to "خانه", "game" to "بازی", "srv" to "سرورها")
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier.clip(shape).background(v.surf.copy(alpha = 0.95f)).border(1.dp, v.line, shape).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, p ->
            val s = i == tab
            Row(
                Modifier
                    .clip(RoundedCornerShape(26.dp))
                    .then(
                        if (s) Modifier.background(Brush.linearGradient(listOf(v.a.copy(alpha = 0.28f), v.b.copy(alpha = 0.28f))))
                        else Modifier
                    )
                    .clickable { onTab(i) }
                    .padding(horizontal = 18.dp, vertical = 12.dp)
                    .animateContentSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ico(p.first, if (s) v.a else v.muted, 22.dp)
                if (s) {
                    Spacer(Modifier.width(8.dp))
                    Text(p.second, color = v.fg, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// ---------- Servers ----------

@Composable
fun ServersScreen(
    store: ProfileStore,
    selId: String,
    onSelect: (String) -> Unit,
    onScan: () -> Unit,
    onFiles: () -> Unit,
    onPaste: () -> Unit
) {
    val v = LocalVT.current
    var q by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Profile?>(null) }
    var delAll by remember { mutableStateOf(false) }
    val shown = store.list.filter { q.isBlank() || it.name.contains(q.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.padding(top = 12.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("سرورها", color = v.fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${store.list.size} مورد", color = v.muted, fontSize = 13.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SoftBtn("اسکن QR", "qr", Modifier.weight(1f)) { onScan() }
            SoftBtn("فایل / زیپ", "file", Modifier.weight(1f)) { onFiles() }
            SoftBtn("چسباندن", "paste", Modifier.weight(1f)) { onPaste() }
        }
        Spacer(Modifier.height(12.dp))
        if (store.list.size > 5) {
            SoftField(q, { q = it }, "جستجو", Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
        if (store.list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(bottom = 100.dp), contentAlignment = Alignment.Center) {
                Text(
                    "هنوز سروری نداری.\nQR بگیر یا فایل .conf و زیپ رو وارد کن.",
                    color = v.muted, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 24.sp
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(shown, key = { it.id }) { p ->
                    val sel = p.id == selId
                    val shape = RoundedCornerShape(24.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(if (sel) v.a.copy(alpha = 0.12f) else v.surf)
                            .border(1.dp, if (sel) v.a.copy(alpha = 0.6f) else v.line, shape)
                            .clickable { onSelect(p.id) }
                            .padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(12.dp).clip(CircleShape).then(
                                if (sel) Modifier.background(Brush.linearGradient(listOf(v.a, v.b)))
                                else Modifier.background(v.line)
                            )
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = v.fg, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("••••••••••", color = v.muted, fontSize = 11.sp)
                        }
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).clickable { del = p },
                            contentAlignment = Alignment.Center
                        ) { Ico("close", v.muted, 16.dp) }
                    }
                }
                item {
                    TextButton(onClick = { delAll = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("حذف همه سرورها", color = v.muted, fontSize = 12.5.sp)
                    }
                }
            }
        }
    }
    val d = del
    if (d != null) {
        AlertDialog(
            onDismissRequest = { del = null },
            containerColor = v.surf, titleContentColor = v.fg, textContentColor = v.muted,
            title = { Text("حذف سرور") },
            text = { Text("«${d.name}» حذف بشه؟") },
            confirmButton = { TextButton({ store.remove(d.id); del = null }) { Text("حذف", color = v.a) } },
            dismissButton = { TextButton({ del = null }) { Text("لغو", color = v.muted) } }
        )
    }
    if (delAll) {
        AlertDialog(
            onDismissRequest = { delAll = false },
            containerColor = v.surf, titleContentColor = v.fg, textContentColor = v.muted,
            title = { Text("حذف همه") },
            text = { Text("همه ${store.list.size} سرور حذف بشن؟ این کار برگشت نداره.") },
            confirmButton = { TextButton({ store.removeAll(); delAll = false }) { Text("حذف همه", color = v.a) } },
            dismissButton = { TextButton({ delAll = false }) { Text("لغو", color = v.muted) } }
        )
    }
}

// ---------- Games ----------

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GamesScreen(
    games: List<GameApp>,
    prefs: Prefs,
    hasProfile: Boolean,
    onLaunch: (GameApp) -> Unit,
    onAdd: () -> Unit,
    onRemove: (GameApp) -> Unit,
    onMsg: (String) -> Unit
) {
    val v = LocalVT.current
    val ctx = LocalContext.current
    var wg by remember { mutableStateOf(prefs.b("gameWg", true)) }
    var dnd by remember { mutableStateOf(prefs.b("gameDnd", false)) }
    var menu by remember { mutableStateOf<GameApp?>(null) }
    val swc = SwitchDefaults.colors(
        checkedThumbColor = v.bg, checkedTrackColor = v.a,
        uncheckedThumbColor = v.muted, uncheckedTrackColor = v.surf, uncheckedBorderColor = v.line
    )
    LazyVerticalGrid(
        GridCells.Fixed(3),
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 110.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 12.dp)) {
                Text("بازی‌ها", color = v.fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("بازی‌هات رو اضافه کن و از اینجا با حالت گیمینگ اجرا کن.", color = v.muted, fontSize = 13.sp)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            val shape = RoundedCornerShape(26.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(v.surf).border(1.dp, v.line, shape)
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("وایرگارد قبل از ورود", color = v.fg, fontSize = 14.sp)
                        Text(
                            if (hasProfile) "سرور انتخاب‌شده خودکار وصل می‌شه" else "اول یه سرور اضافه کن",
                            color = v.muted, fontSize = 12.sp
                        )
                    }
                    Switch(wg, { wg = it; prefs.put("gameWg", it) }, colors = swc)
                }
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("مزاحم نشوید حین بازی", color = v.fg, fontSize = 14.sp)
                        Text("نیاز به مجوز دارد. با برگشت به ویرا خاموش می‌شه", color = v.muted, fontSize = 12.sp)
                    }
                    Switch(dnd, {
                        dnd = it
                        prefs.put("gameDnd", it)
                        if (it && !Game.dndGranted(ctx)) {
                            Game.dndSettings(ctx)
                            onMsg("مجوز «مزاحم نشوید» رو بده و برگرد")
                        }
                    }, colors = swc)
                }
            }
        }
        gridItems(games, key = { it.pkg }) { g ->
            val ishape = RoundedCornerShape(20.dp)
            Column(
                Modifier.combinedClickable(onClick = { onLaunch(g) }, onLongClick = { menu = g }),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(72.dp).clip(ishape).background(v.surf)
                        .border(1.5.dp, Brush.linearGradient(listOf(v.a, v.b)), ishape),
                    contentAlignment = Alignment.Center
                ) {
                    val ic = g.icon
                    if (ic != null) {
                        Image(ic, null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    g.label, color = v.fg, fontSize = 11.5.sp, maxLines = 2,
                    textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp
                )
            }
        }
        item {
            Column(Modifier.clickable { onAdd() }, horizontalAlignment = Alignment.CenterHorizontally) {
                val ishape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.size(72.dp).clip(ishape).background(v.surf).border(1.dp, v.line, ishape),
                    contentAlignment = Alignment.Center
                ) { Ico("plus", v.a, 26.dp) }
                Spacer(Modifier.height(6.dp))
                Text("افزودن", color = v.muted, fontSize = 11.5.sp)
            }
        }
    }
    val m = menu
    if (m != null) {
        AlertDialog(
            onDismissRequest = { menu = null },
            containerColor = v.surf, titleContentColor = v.fg, textContentColor = v.muted,
            title = { Text(m.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton({ Game.appInfo(ctx, m.pkg); menu = null }) {
                        Text("اطلاعات برنامه (پاک کردن کش)", color = v.a)
                    }
                    TextButton({ onRemove(m); menu = null }) { Text("حذف از لیست", color = v.a) }
                }
            },
            confirmButton = { TextButton({ menu = null }) { Text("بستن", color = v.muted) } }
        )
    }
}

@Composable
fun GamePicker(selected: List<String>, onToggle: (String) -> Unit, onDone: () -> Unit) {
    val v = LocalVT.current
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val apps by produceState<List<GameApp>?>(null) {
        value = withContext(Dispatchers.IO) { Game.loadAll(ctx) }
    }
    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Bg {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
                Row(Modifier.padding(top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("کدوم برنامه‌ها بازی هستن؟", color = v.fg, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onDone) { Text("تأیید", color = v.a, fontSize = 15.sp) }
                }
                SoftField(q, { q = it }, "جستجوی برنامه", Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                val l = apps
                if (l == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("در حال خواندن برنامه‌ها…", color = v.muted, fontSize = 14.sp)
                    }
                } else {
                    val f = l.filter { q.isBlank() || it.label.contains(q.trim(), ignoreCase = true) }
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(f, key = { it.pkg }) { g ->
                            val on = g.pkg in selected
                            val shape = RoundedCornerShape(20.dp)
                            Row(
                                Modifier.fillMaxWidth().clip(shape)
                                    .background(if (on) v.a.copy(alpha = 0.12f) else v.surf)
                                    .clickable { onToggle(g.pkg) }
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val ic = g.icon
                                if (ic != null) Image(ic, null, Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(g.label, color = v.fg, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (g.known) Text("بازی شناخته‌شده", color = v.a, fontSize = 11.sp)
                                }
                                Box(
                                    Modifier.size(26.dp).clip(CircleShape).then(
                                        if (on) Modifier.background(Brush.linearGradient(listOf(v.a, v.b)))
                                        else Modifier.border(1.5.dp, v.line, CircleShape)
                                    ),
                                    contentAlignment = Alignment.Center
                                ) { if (on) Ico("check", v.bg, 16.dp) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Short game-mode intro: a charging ring around the game icon, then the game opens. */
@Composable
fun LaunchOverlay(g: GameApp, prog: () -> Float, step: String) {
    val v = LocalVT.current
    val spin = rememberInfiniteTransition(label = "o").animateFloat(
        0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "os"
    )
    Box(
        Modifier.fillMaxSize().background(v.bg).clickable(enabled = true) { },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0 until 9) {
                val y = size.height * (0.08f + i * 0.11f)
                drawLine(v.a.copy(alpha = 0.06f), Offset(0f, y + 70f), Offset(size.width, y - 70f), 2.dp.toPx())
            }
            val c = Offset(size.width / 2f, size.height * 0.45f)
            drawCircle(
                Brush.radialGradient(listOf(v.a.copy(alpha = 0.28f), androidx.compose.ui.graphics.Color.Transparent), c, size.width * 0.8f),
                size.width * 0.8f, c
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val r = size.minDimension * 0.44f
                    rotate(spin.value, c) {
                        drawCircle(
                            v.b.copy(alpha = 0.55f), r * 1.12f, c,
                            style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 16f)))
                        )
                    }
                    drawCircle(v.line, r, c, style = Stroke(7.dp.toPx()))
                    rotate(-90f, c) {
                        drawArc(
                            Brush.sweepGradient(listOf(v.a, v.b, v.a), c), 0f, 360f * prog(), false,
                            Offset(c.x - r, c.y - r), Size(r * 2, r * 2),
                            style = Stroke(7.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
                val ic = g.icon
                if (ic != null) Image(ic, null, Modifier.size(100.dp).clip(RoundedCornerShape(26.dp)))
            }
            Spacer(Modifier.height(26.dp))
            Text("GAME MODE", color = v.a, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
            Spacer(Modifier.height(8.dp))
            Text(g.label, color = v.fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(step, color = v.muted, fontSize = 13.sp)
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(
    pal: Int,
    onPal: (Int) -> Unit,
    secure: Boolean,
    onSecure: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    val v = LocalVT.current
    val ctx = LocalContext.current
    LazyVerticalGrid(
        GridCells.Fixed(5),
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 40.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.padding(top = 10.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(v.surf).clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) { Ico("back", v.fg) }
                Spacer(Modifier.width(14.dp))
                Text("تنظیمات", color = v.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 8.dp)) {
                Text("رنگ برنامه", color = v.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("${PALS[pal].name} · ${PALS.size} رنگ", color = v.muted, fontSize = 12.5.sp)
            }
        }
        items(PALS.size) { i ->
            val p = PALS[i]
            val on = i == pal
            Box(
                Modifier.size(54.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.Color(p.a), androidx.compose.ui.graphics.Color(p.b))))
                    .then(if (on) Modifier.border(3.dp, v.fg, CircleShape) else Modifier)
                    .clickable { onPal(i) },
                contentAlignment = Alignment.Center
            ) { if (on) Ico("check", androidx.compose.ui.graphics.Color(0xFF0A0F1C), 22.dp) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            val shape = RoundedCornerShape(26.dp)
            Column(Modifier.padding(top = 14.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(shape).background(v.surf).border(1.dp, v.line, shape)
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("مخفی‌سازی صفحه", color = v.fg, fontSize = 14.sp)
                        Text("جلوی اسکرین‌شات و نمایش تو لیست برنامه‌های اخیر", color = v.muted, fontSize = 12.sp)
                    }
                    Switch(
                        secure, onSecure,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = v.bg, checkedTrackColor = v.a,
                            uncheckedThumbColor = v.muted, uncheckedTrackColor = v.surf, uncheckedBorderColor = v.line
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "کلیدهای وایرگارد رمزنگاری‌شده ذخیره می‌شن و هیچ‌جای برنامه نمایش داده نمی‌شن.",
                    color = v.muted, fontSize = 12.sp, lineHeight = 19.sp
                )
                TextButton(onClick = { openUrl(ctx, "https://t.me/PINGAMIRREZA") }) {
                    Text("پشتیبانی در تلگرام", color = v.a, fontSize = 14.sp)
                }
                Text("ویرا · نسخه 1.0", color = v.muted, fontSize = 12.sp)
            }
        }
    }
}

fun openUrl(ctx: Context, url: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
    }
}
