package com.vira.wg

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

class Acct(val name: String, val email: String)

/** Google sign-in. Only the name and e-mail stay on this phone; nothing is sent to any server of ours. */
object Account {
    fun enabled(): Boolean = Config.GOOGLE_CLIENT_ID.isNotBlank()

    fun load(p: Prefs): Acct? {
        val e = p.s("acct_mail")
        return if (e.isBlank()) null else Acct(p.s("acct_name"), e)
    }

    suspend fun signIn(act: Activity, p: Prefs): Acct? {
        return try {
            val opt = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(Config.GOOGLE_CLIENT_ID)
                .build()
            val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
            val c = CredentialManager.create(act).getCredential(act, req).credential
            if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(c.data)
                p.put("acct_name", g.displayName ?: "")
                p.put("acct_mail", g.id)
                Acct(g.displayName ?: "", g.id)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun signOut(ctx: Context, p: Prefs) {
        try {
            CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
        }
        p.put("acct_name", "")
        p.put("acct_mail", "")
    }
}
