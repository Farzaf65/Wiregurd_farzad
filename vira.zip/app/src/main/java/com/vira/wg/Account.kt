package com.vira.wg

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

class Acct(val name: String, val email: String)

/** Google sign-in. Only the name and e-mail stay on this phone; nothing is sent to any server of ours. */
object Account {
    fun enabled(): Boolean = Config.GOOGLE_CLIENT_ID.isNotBlank()

    fun load(p: Prefs): Acct? {
        val e = p.s("acct_mail")
        return if (e.isBlank()) null else Acct(p.s("acct_name"), e)
    }

    /** Short reason of the last failed attempt, shown to help find the cause. */
    var lastError: String = ""

    private suspend fun ask(act: Activity, opt: androidx.credentials.CredentialOption): GoogleIdTokenCredential? {
        val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
        val c = CredentialManager.create(act).getCredential(act, req).credential
        return if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            GoogleIdTokenCredential.createFrom(c.data)
        } else null
    }

    suspend fun signIn(act: Activity, p: Prefs): Acct? {
        lastError = ""
        var g: GoogleIdTokenCredential? = null
        try {
            g = ask(
                act,
                GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false)
                    .setServerClientId(Config.GOOGLE_CLIENT_ID).build()
            )
        } catch (e: androidx.credentials.exceptions.GetCredentialCancellationException) {
            lastError = "لغو شد"
            return null
        } catch (e: Exception) {
            lastError = (e.javaClass.simpleName + ": " + (e.message ?: "")).take(90)
        }
        if (g == null) {
            // Second way: the full "Sign in with Google" sheet.
            try {
                g = ask(
                    act,
                    com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
                        .Builder(Config.GOOGLE_CLIENT_ID).build()
                )
            } catch (e: androidx.credentials.exceptions.GetCredentialCancellationException) {
                lastError = "لغو شد"
                return null
            } catch (e: Exception) {
                lastError = (e.javaClass.simpleName + ": " + (e.message ?: "")).take(90)
            }
        }
        if (g == null) return null
        lastError = ""
        p.put("acct_name", g.displayName ?: "")
        p.put("acct_mail", g.id)
        return Acct(g.displayName ?: "", g.id)
    }

    suspend fun signOut(ctx: Context, p: Prefs) {
        try {
            CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
        }
        p.put("acct_name", "")
        p.put("acct_mail", "")
    }
}
