package com.vira.wg

import android.graphics.Color as AColor
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

class Pal(val name: String, val a: Long, val b: Long)

/** 30 color pairs. The dark background is derived from the hue of the first color. */
val PALS = listOf(
    Pal("اقیانوس", 0xFF22D3EE, 0xFF3B82F6),
    Pal("یخ‌چال", 0xFF67E8F9, 0xFFA5B4FC),
    Pal("زمرد", 0xFF34D399, 0xFF22D3EE),
    Pal("جنگل", 0xFF4ADE80, 0xFFA3E635),
    Pal("لیمو", 0xFFA3E635, 0xFFFACC15),
    Pal("خورشید", 0xFFFACC15, 0xFFFB923C),
    Pal("مرجان", 0xFFFB923C, 0xFFF43F5E),
    Pal("آتش", 0xFFF97316, 0xFFEF4444),
    Pal("یاقوت", 0xFFF43F5E, 0xFFFB7185),
    Pal("گل‌سرخ", 0xFFFB7185, 0xFFF472B6),
    Pal("صورتی", 0xFFF472B6, 0xFFC084FC),
    Pal("ارغوان", 0xFFC084FC, 0xFF818CF8),
    Pal("بنفش", 0xFFA78BFA, 0xFF60A5FA),
    Pal("نیلی", 0xFF818CF8, 0xFF38BDF8),
    Pal("آسمان", 0xFF38BDF8, 0xFF2DD4BF),
    Pal("فیروزه", 0xFF2DD4BF, 0xFF4ADE80),
    Pal("نعناع", 0xFF5EEAD4, 0xFF86EFAC),
    Pal("شفق", 0xFF22D3EE, 0xFFC084FC),
    Pal("غروب", 0xFFFB923C, 0xFFC084FC),
    Pal("نئون", 0xFF00F5A0, 0xFF00D9F5),
    Pal("سایبر", 0xFFFF2E97, 0xFF00E5FF),
    Pal("طلا", 0xFFFDE047, 0xFFF59E0B),
    Pal("مس", 0xFFFDBA74, 0xFFF87171),
    Pal("عقیق", 0xFFF87171, 0xFFFBBF24),
    Pal("توت", 0xFFE879F9, 0xFF818CF8),
    Pal("اطلسی", 0xFFE879F9, 0xFFF472B6),
    Pal("دریا", 0xFF06B6D4, 0xFF2563EB),
    Pal("نقره", 0xFFCBD5E1, 0xFF94A3B8),
    Pal("پسته", 0xFFBEF264, 0xFF2DD4BF),
    Pal("کاکائو", 0xFFD6A77A, 0xFFF59E0B)
)

class VT(
    val a: Color,
    val b: Color,
    val bg: Color,
    val surf: Color,
    val line: Color,
    val fg: Color,
    val muted: Color,
    /** All chosen colors (at least two). Used for rings and glows. */
    val mix: List<Color> = listOf(a, b)
)

/** What the user picked: 1..5 colors (first = main) and a background index (-1 = automatic). */
class Look(val cols: List<Long>, val bg: Int = -1)

class Grad(val name: String, val c1: Long, val c2: Long, val c3: Long)
class Bgd(val name: String, val c: Long)

val BGS = listOf(
    Bgd("نیمه‌شب", 0xFF070B12), Bgd("مشکی (آمولد)", 0xFF000000), Bgd("گرافیت", 0xFF0E1013),
    Bgd("اقیانوس شب", 0xFF06101C), Bgd("بنفش تیره", 0xFF0B0716), Bgd("شب جنگلی", 0xFF06120D),
    Bgd("شراب", 0xFF140609), Bgd("قهوه‌ای تیره", 0xFF120D08), Bgd("آبی نفتی", 0xFF04141A),
    Bgd("خاکستری آبی", 0xFF111723)
)

val SOLIDS = listOf(
    0xFF22D3EE, 0xFF38BDF8, 0xFF3B82F6, 0xFF818CF8, 0xFF7C5CFF,
    0xFFA78BFA, 0xFFC084FC, 0xFFE879F9, 0xFFF472B6, 0xFFFB7185,
    0xFFF43F5E, 0xFFEF4444, 0xFFFB923C, 0xFFFACC15, 0xFFA3E635,
    0xFF4ADE80, 0xFF34D399, 0xFF2DD4BF, 0xFFCBD5E1, 0xFFD6A77A
)

val GAMING = listOf(
    0xFF00F5A0 to 0xFF00D9F5, 0xFFFF2E97 to 0xFF00E5FF, 0xFF7C5CFF to 0xFF00E5FF, 0xFF22FF88 to 0xFF00C853,
    0xFFFF3D81 to 0xFF7C4DFF, 0xFFFF9F1C to 0xFFFF4D4D, 0xFF00E5FF to 0xFF2979FF, 0xFFB6FF00 to 0xFF00E676,
    0xFFFF5722 to 0xFFFFC107, 0xFFFF1744 to 0xFF9B5CFF
)

val GIRLS = listOf(
    0xFFF472B6 to 0xFFFB7185, 0xFFFDA4AF to 0xFFF9A8D4, 0xFFE879F9 to 0xFFF472B6, 0xFFC4B5FD to 0xFFF9A8D4,
    0xFFFBCFE8 to 0xFFD8B4FE, 0xFFFF8FAB to 0xFFFFB3C6, 0xFFF9A8D4 to 0xFFA5B4FC, 0xFFFDBA74 to 0xFFF9A8D4,
    0xFFD946EF to 0xFF8B5CF6, 0xFFFB7185 to 0xFFFBBF24
)

val BOYS = listOf(
    0xFF3B82F6 to 0xFF22D3EE, 0xFF2563EB to 0xFF7C3AED, 0xFF0EA5E9 to 0xFF14B8A6, 0xFF10B981 to 0xFF3B82F6,
    0xFF94A3B8 to 0xFF38BDF8, 0xFF4F7CFF to 0xFF06B6D4, 0xFF06B6D4 to 0xFF2563EB, 0xFF84CC16 to 0xFF10B981,
    0xFFF59E0B to 0xFFEF4444, 0xFF60A5FA to 0xFF818CF8
)

val GRADS = listOf(
    Grad("بنفش ملکوتی", 0xFF7C5CFF, 0xFFC084FC, 0xFFF472B6),
    Grad("اقیانوس عمیق", 0xFF22D3EE, 0xFF3B82F6, 0xFF7C5CFF),
    Grad("غروب گرم", 0xFFFACC15, 0xFFFB923C, 0xFFF43F5E),
    Grad("شفق قطبی", 0xFF34D399, 0xFF22D3EE, 0xFFA78BFA),
    Grad("آتشفشان", 0xFFFF5722, 0xFFF43F5E, 0xFF9B5CFF),
    Grad("نعناع و آسمان", 0xFF86EFAC, 0xFF5EEAD4, 0xFF38BDF8),
    Grad("آبنبات", 0xFFF9A8D4, 0xFFC4B5FD, 0xFF93C5FD),
    Grad("نئون شب", 0xFF00F5A0, 0xFF00D9F5, 0xFFFF2E97),
    Grad("طلای سلطنتی", 0xFFFDE047, 0xFFF59E0B, 0xFFFB7185),
    Grad("یخ و نقره", 0xFFE2E8F0, 0xFF93C5FD, 0xFF818CF8),
    Grad("جنگل شب", 0xFFA3E635, 0xFF34D399, 0xFF22D3EE),
    Grad("گل‌سرخ", 0xFFFB7185, 0xFFE879F9, 0xFF818CF8)
)

fun makeTheme(l: Look): VT {
    val cols = l.cols.map { Color(it) }.ifEmpty { listOf(Color(PALS[0].a), Color(PALS[0].b)) }
    val a = cols[0]
    val hsv = FloatArray(3)
    AColor.colorToHSV(a.toArgb(), hsv)
    val h = hsv[0]
    val b = cols.getOrNull(1) ?: Color.hsv((h + 28f) % 360f, (hsv[1] * 0.85f).coerceIn(0f, 1f), 1f)
    val mix = if (cols.size >= 2) cols else listOf(a, b)
    val fg = Color(0xFFF1F5F9)
    if (l.bg in BGS.indices) {
        val bg = Color(BGS[l.bg].c)
        return VT(a, b, bg, lerp(bg, Color.White, 0.07f), lerp(bg, Color.White, 0.17f), fg, lerp(fg, bg, 0.42f), mix)
    }
    return VT(
        a, b,
        Color.hsv(h, 0.5f, 0.06f),
        Color.hsv(h, 0.4f, 0.11f),
        Color.hsv(h, 0.35f, 0.2f),
        fg,
        Color.hsv(h, 0.12f, 0.66f),
        mix
    )
}

/** Saves and loads the look so it survives closing the app. */
object LookStore {
    val DEFAULT = Look(listOf(PALS[0].a, PALS[0].b), -1)

    fun load(p: Prefs): Look {
        val cols = p.s("cols").split(",").mapNotNull { it.trim().toLongOrNull(16) }.take(5)
        val bg = p.i("bg", -1).let { if (it in BGS.indices) it else -1 }
        if (cols.isNotEmpty()) return Look(cols, bg)
        val old = PALS[p.i("pal", 0).coerceIn(0, PALS.size - 1)]
        return Look(listOf(old.a, old.b), bg)
    }

    fun save(p: Prefs, l: Look) {
        p.put("cols", l.cols.joinToString(",") { java.lang.Long.toHexString(it) })
        p.put("bg", l.bg)
    }
}

val LocalVT = staticCompositionLocalOf { makeTheme(LookStore.DEFAULT) }
