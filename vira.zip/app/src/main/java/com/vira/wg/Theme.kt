package com.vira.wg

import android.graphics.Color as AColor
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

class Pal(val name: String, val a: Long, val b: Long)

/** 30 color pairs. The dark background is derived from the hue of the first color. */
val PALS = listOf(
    Pal("اقیانوس", 0xFF22D3EE, 0xFF3B82F6),
    Pal("یخ‌چال", 0xFF67E8F9, 0xFFA5B4FC),
    Pal("زمرد", 0xFF34D399, 0xFF22D3EE),
    Pal("جنگل", 0xFF4ADE80, 0xFFA3E635),
    Pal("لیمو", 0xFFA3E635, 0xFFFACC15),
    Pal("خورشید", 0xFFFACC15, 0xFFFB923C),
    Pal("مرجان", 0xFFFB923C, 0xFFF43F5E),
    Pal("آتش", 0xFFF97316, 0xFFEF4444),
    Pal("یاقوت", 0xFFF43F5E, 0xFFFB7185),
    Pal("گل‌سرخ", 0xFFFB7185, 0xFFF472B6),
    Pal("صورتی", 0xFFF472B6, 0xFFC084FC),
    Pal("ارغوان", 0xFFC084FC, 0xFF818CF8),
    Pal("بنفش", 0xFFA78BFA, 0xFF60A5FA),
    Pal("نیلی", 0xFF818CF8, 0xFF38BDF8),
    Pal("آسمان", 0xFF38BDF8, 0xFF2DD4BF),
    Pal("فیروزه", 0xFF2DD4BF, 0xFF4ADE80),
    Pal("نعناع", 0xFF5EEAD4, 0xFF86EFAC),
    Pal("شفق", 0xFF22D3EE, 0xFFC084FC),
    Pal("غروب", 0xFFFB923C, 0xFFC084FC),
    Pal("نئون", 0xFF00F5A0, 0xFF00D9F5),
    Pal("سایبر", 0xFFFF2E97, 0xFF00E5FF),
    Pal("طلا", 0xFFFDE047, 0xFFF59E0B),
    Pal("مس", 0xFFFDBA74, 0xFFF87171),
    Pal("عقیق", 0xFFF87171, 0xFFFBBF24),
    Pal("توت", 0xFFE879F9, 0xFF818CF8),
    Pal("اطلسی", 0xFFE879F9, 0xFFF472B6),
    Pal("دریا", 0xFF06B6D4, 0xFF2563EB),
    Pal("نقره", 0xFFCBD5E1, 0xFF94A3B8),
    Pal("پسته", 0xFFBEF264, 0xFF2DD4BF),
    Pal("کاکائو", 0xFFD6A77A, 0xFFF59E0B)
)

class VT(
    val a: Color,
    val b: Color,
    val bg: Color,
    val surf: Color,
    val line: Color,
    val fg: Color,
    val muted: Color
)

fun makeTheme(p: Pal): VT {
    val a = Color(p.a)
    val b = Color(p.b)
    val hsv = FloatArray(3)
    AColor.colorToHSV(a.toArgb(), hsv)
    val h = hsv[0]
    return VT(
        a, b,
        Color.hsv(h, 0.5f, 0.06f),
        Color.hsv(h, 0.4f, 0.11f),
        Color.hsv(h, 0.35f, 0.2f),
        Color(0xFFF1F5F9),
        Color.hsv(h, 0.12f, 0.66f)
    )
}

val LocalVT = staticCompositionLocalOf { makeTheme(PALS[0]) }
