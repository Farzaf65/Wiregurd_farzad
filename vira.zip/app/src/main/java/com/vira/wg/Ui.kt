package com.vira.wg

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.animation.core.Easing
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Bg(content: @Composable BoxScope.() -> Unit) {
    val v = LocalVT.current
    Box(
        Modifier
            .fillMaxSize()
            .background(v.bg)
            .drawBehind {
                val c1 = Offset(size.width * 0.5f, 0f)
                val r1 = size.width * 0.95f
                drawCircle(Brush.radialGradient(listOf(v.a.copy(alpha = 0.20f), Color.Transparent), c1, r1), r1, c1)
                val c2 = Offset(size.width, size.height * 0.85f)
                val r2 = size.width * 0.8f
                drawCircle(Brush.radialGradient(listOf(v.b.copy(alpha = 0.14f), Color.Transparent), c2, r2), r2, c2)
            },
        content = content
    )
}

@Composable
fun Ico(kind: String, color: Color, sz: Dp = 22.dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val sw = w * 0.085f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "home" -> {
                val p = Path()
                p.moveTo(w * .14f, w * .48f); p.lineTo(w * .5f, w * .16f); p.lineTo(w * .86f, w * .48f)
                p.moveTo(w * .24f, w * .42f); p.lineTo(w * .24f, w * .82f); p.lineTo(w * .76f, w * .82f); p.lineTo(w * .76f, w * .42f)
                drawPath(p, color, style = st)
            }
            "game" -> {
                drawRoundRect(color, Offset(w * .1f, w * .28f), Size(w * .8f, w * .46f), CornerRadius(w * .22f), style = st)
                drawLine(color, Offset(w * .3f, w * .44f), Offset(w * .3f, w * .58f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .23f, w * .51f), Offset(w * .37f, w * .51f), sw, StrokeCap.Round)
                drawCircle(color, w * .045f, Offset(w * .66f, w * .46f))
                drawCircle(color, w * .045f, Offset(w * .75f, w * .56f))
            }
            "srv" -> {
                drawRoundRect(color, Offset(w * .14f, w * .16f), Size(w * .72f, w * .26f), CornerRadius(w * .1f), style = st)
                drawRoundRect(color, Offset(w * .14f, w * .58f), Size(w * .72f, w * .26f), CornerRadius(w * .1f), style = st)
                drawCircle(color, w * .04f, Offset(w * .27f, w * .29f))
                drawCircle(color, w * .04f, Offset(w * .27f, w * .71f))
            }
            "sliders" -> {
                drawLine(color, Offset(w * .14f, w * .3f), Offset(w * .86f, w * .3f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .14f, w * .7f), Offset(w * .86f, w * .7f), sw, StrokeCap.Round)
                drawCircle(color, w * .11f, Offset(w * .64f, w * .3f))
                drawCircle(color, w * .11f, Offset(w * .36f, w * .7f))
            }
            "qr" -> {
                val s = w * .26f
                drawRoundRect(color, Offset(w * .14f, w * .14f), Size(s, s), CornerRadius(w * .05f), style = st)
                drawRoundRect(color, Offset(w * .6f, w * .14f), Size(s, s), CornerRadius(w * .05f), style = st)
                drawRoundRect(color, Offset(w * .14f, w * .6f), Size(s, s), CornerRadius(w * .05f), style = st)
                drawCircle(color, w * .045f, Offset(w * .66f, w * .66f))
                drawCircle(color, w * .045f, Offset(w * .82f, w * .82f))
                drawCircle(color, w * .045f, Offset(w * .82f, w * .66f))
            }
            "file" -> {
                drawRoundRect(color, Offset(w * .22f, w * .14f), Size(w * .56f, w * .72f), CornerRadius(w * .09f), style = st)
                drawLine(color, Offset(w * .36f, w * .42f), Offset(w * .64f, w * .42f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .36f, w * .58f), Offset(w * .6f, w * .58f), sw, StrokeCap.Round)
            }
            "paste" -> {
                drawRoundRect(color, Offset(w * .2f, w * .2f), Size(w * .6f, w * .68f), CornerRadius(w * .09f), style = st)
                drawRoundRect(color, Offset(w * .36f, w * .1f), Size(w * .28f, w * .16f), CornerRadius(w * .05f), style = st)
            }
            "close" -> {
                drawLine(color, Offset(w * .25f, w * .25f), Offset(w * .75f, w * .75f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .75f, w * .25f), Offset(w * .25f, w * .75f), sw, StrokeCap.Round)
            }
            "plus" -> {
                drawLine(color, Offset(w * .5f, w * .2f), Offset(w * .5f, w * .8f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .5f), Offset(w * .8f, w * .5f), sw, StrokeCap.Round)
            }
            "check" -> {
                val p = Path()
                p.moveTo(w * .22f, w * .52f); p.lineTo(w * .43f, w * .72f); p.lineTo(w * .78f, w * .3f)
                drawPath(p, color, style = st)
            }
            "edit" -> {
                drawLine(color, Offset(w * .32f, w * .68f), Offset(w * .7f, w * .3f), sw * 2.4f, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .84f), Offset(w * .55f, w * .84f), sw, StrokeCap.Round)
            }
            "dice" -> {
                drawRoundRect(color, Offset(w * .16f, w * .16f), Size(w * .68f, w * .68f), CornerRadius(w * .16f), style = st)
                drawCircle(color, w * .055f, Offset(w * .36f, w * .36f))
                drawCircle(color, w * .055f, Offset(w * .5f, w * .5f))
                drawCircle(color, w * .055f, Offset(w * .64f, w * .64f))
            }
            "menu" -> {
                drawLine(color, Offset(w * .2f, w * .3f), Offset(w * .8f, w * .3f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .5f), Offset(w * .8f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .7f), Offset(w * .55f, w * .7f), sw, StrokeCap.Round)
            }
            "chev" -> {
                val p = Path()
                p.moveTo(w * .25f, w * .38f); p.lineTo(w * .5f, w * .64f); p.lineTo(w * .75f, w * .38f)
                drawPath(p, color, style = st)
            }
            "palette" -> {
                drawCircle(color, w * .36f, Offset(w * .5f, w * .5f), style = st)
                drawCircle(color, w * .05f, Offset(w * .36f, w * .44f))
                drawCircle(color, w * .05f, Offset(w * .52f, w * .34f))
                drawCircle(color, w * .05f, Offset(w * .66f, w * .46f))
                drawCircle(color, w * .05f, Offset(w * .6f, w * .62f))
            }
            "bolt" -> {
                val p = Path()
                p.moveTo(w * .56f, w * .14f); p.lineTo(w * .28f, w * .54f); p.lineTo(w * .48f, w * .54f)
                p.lineTo(w * .42f, w * .86f); p.lineTo(w * .72f, w * .44f); p.lineTo(w * .52f, w * .44f)
                p.close()
                drawPath(p, color, style = st)
            }
            "reset" -> {
                drawArc(
                    color, -50f, 290f, false, Offset(w * .2f, w * .2f), Size(w * .6f, w * .6f), style = st
                )
                val p = Path()
                p.moveTo(w * .66f, w * .12f); p.lineTo(w * .72f, w * .28f); p.lineTo(w * .56f, w * .3f)
                drawPath(p, color, style = st)
            }
            "app" -> {
                drawRoundRect(color, Offset(w * .18f, w * .18f), Size(w * .64f, w * .64f), CornerRadius(w * .2f), style = st)
                drawCircle(color, w * .1f, Offset(w * .5f, w * .5f), style = st)
            }
            "shield" -> {
                val p = Path()
                p.moveTo(w * .5f, w * .14f); p.lineTo(w * .82f, w * .26f); p.lineTo(w * .82f, w * .5f)
                p.lineTo(w * .5f, w * .86f); p.lineTo(w * .18f, w * .5f); p.lineTo(w * .18f, w * .26f)
                p.close()
                drawPath(p, color, style = st)
            }
            "send" -> {
                val p = Path()
                p.moveTo(w * .84f, w * .16f); p.lineTo(w * .14f, w * .46f); p.lineTo(w * .44f, w * .58f)
                p.lineTo(w * .56f, w * .86f); p.close()
                drawPath(p, color, style = st)
                drawLine(color, Offset(w * .44f, w * .58f), Offset(w * .84f, w * .16f), sw, StrokeCap.Round)
            }
            "mail" -> {
                drawRoundRect(color, Offset(w * .12f, w * .22f), Size(w * .76f, w * .56f), CornerRadius(w * .12f), style = st)
                val p = Path()
                p.moveTo(w * .16f, w * .32f); p.lineTo(w * .5f, w * .56f); p.lineTo(w * .84f, w * .32f)
                drawPath(p, color, style = st)
            }
            "chat" -> {
                drawRoundRect(color, Offset(w * .12f, w * .16f), Size(w * .76f, w * .5f), CornerRadius(w * .2f), style = st)
                val p = Path()
                p.moveTo(w * .34f, w * .66f); p.lineTo(w * .3f, w * .84f); p.lineTo(w * .52f, w * .66f)
                drawPath(p, color, style = st)
                drawCircle(color, w * .04f, Offset(w * .35f, w * .41f))
                drawCircle(color, w * .04f, Offset(w * .5f, w * .41f))
                drawCircle(color, w * .04f, Offset(w * .65f, w * .41f))
            }
            "wave" -> {
                drawCircle(color, w * .07f, Offset(w * .5f, w * .5f))
                for (r in listOf(w * .2f, w * .34f)) {
                    drawArc(color, -45f, 90f, false, Offset(w * .5f - r, w * .5f - r), Size(r * 2, r * 2), style = st)
                    drawArc(color, 135f, 90f, false, Offset(w * .5f - r, w * .5f - r), Size(r * 2, r * 2), style = st)
                }
            }
            "share" -> {
                drawCircle(color, w * .09f, Offset(w * .26f, w * .5f), style = st)
                drawCircle(color, w * .09f, Offset(w * .74f, w * .24f), style = st)
                drawCircle(color, w * .09f, Offset(w * .74f, w * .76f), style = st)
                drawLine(color, Offset(w * .34f, w * .46f), Offset(w * .66f, w * .28f), w * .06f)
                drawLine(color, Offset(w * .34f, w * .54f), Offset(w * .66f, w * .72f), w * .06f)
            }
            "user" -> {
                drawCircle(color, w * .17f, Offset(w * .5f, w * .34f), style = st)
                drawArc(color, 180f, 180f, false, Offset(w * .2f, w * .56f), Size(w * .6f, w * .5f), style = st)
            }
            "back" -> {
                val p = Path()
                p.moveTo(w * .62f, w * .2f); p.lineTo(w * .3f, w * .5f); p.lineTo(w * .62f, w * .8f)
                drawPath(p, color, style = st)
            }
        }
    }
}

/** The start button. state: 0 off, 1 connecting, 2 connected. Animations run only while needed. */
@Composable
fun Orb(state: Int, onClick: () -> Unit) {
    val v = LocalVT.current
    val on by animateFloatAsState(if (state == 2) 1f else 0f, tween(700), label = "on")
    val press = remember { MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else 1f, tween(160), label = "sc")
    Box(
        Modifier
            .size(280.dp)
            .graphicsLayer {
                scaleX = sc
                scaleY = sc
            }
            .clickable(interactionSource = press, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (state == 2) Breath()
        if (state == 1) Spinner()
        Canvas(Modifier.size(280.dp)) {
            val c = center
            val r = size.minDimension * 0.30f
            if (on > 0f) {
                drawCircle(
                    Brush.radialGradient(listOf(v.a.copy(alpha = 0.35f * on), Color.Transparent), c, r * 1.9f),
                    r * 1.9f, c
                )
            }
            drawCircle(v.surf, r, c)
            drawCircle(
                Brush.sweepGradient(v.mix + v.mix.first(), c), r, c,
                alpha = 0.6f * (1f - on), style = Stroke(3.dp.toPx())
            )
            if (on > 0f) {
                drawCircle(
                    Brush.linearGradient(v.mix, Offset(c.x - r, c.y - r), Offset(c.x + r, c.y + r)),
                    r, c, alpha = on
                )
            }
            val gc = lerp(v.muted, v.bg, on)
            val gr = r * 0.42f
            val gw = r * 0.11f
            drawArc(
                gc, -50f, 280f, false,
                Offset(c.x - gr, c.y - gr + r * 0.05f), Size(gr * 2, gr * 2),
                style = Stroke(gw, cap = StrokeCap.Round)
            )
            drawLine(gc, Offset(c.x, c.y - gr * 1.1f), Offset(c.x, c.y - gr * 0.1f), gw, StrokeCap.Round)
        }
    }
}

/** Battery-saver mode: ambient animations stand still and cost nothing. */
val LocalSaver = staticCompositionLocalOf { false }

@Composable
fun loopF(from: Float, to: Float, ms: Int, reverse: Boolean, easing: Easing): State<Float> {
    if (LocalSaver.current) return remember { mutableStateOf((from + to) / 2f) }
    return rememberInfiniteTransition(label = "loop").animateFloat(
        from, to,
        infiniteRepeatable(tween(ms, easing = easing), if (reverse) RepeatMode.Reverse else RepeatMode.Restart),
        label = "lp"
    )
}

@Composable
private fun Breath() {
    val v = LocalVT.current
    val t = loopF(0f, 1f, 2800, true, FastOutSlowInEasing)
    Canvas(Modifier.size(280.dp)) {
        val r = size.minDimension * 0.30f
        val k = t.value
        drawCircle(v.a.copy(alpha = 0.10f + 0.12f * (1f - k)), r * (1.15f + 0.30f * k), center)
        drawCircle(v.b.copy(alpha = 0.12f), r * (1.05f + 0.12f * k), center, style = Stroke(2.dp.toPx()))
    }
}

@Composable
private fun Spinner() {
    val v = LocalVT.current
    val a = rememberInfiniteTransition(label = "s").animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "sa"
    )
    Canvas(Modifier.size(280.dp)) {
        val rr = size.minDimension * 0.30f * 1.14f
        rotate(a.value, center) {
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, v.a), center), 0f, 270f, false,
                Offset(center.x - rr, center.y - rr), Size(rr * 2, rr * 2),
                style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun SoftField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    minLines: Int = 1
) {
    val v = LocalVT.current
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier
            .clip(shape)
            .background(v.surf)
            .border(1.dp, v.line, shape)
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = v.muted, fontSize = 14.sp)
        BasicTextField(
            value, onChange, Modifier.fillMaxWidth(),
            textStyle = TextStyle(color = v.fg, fontSize = 14.sp),
            cursorBrush = SolidColor(v.a),
            minLines = minLines
        )
    }
}

/** Soft rounded action with an icon and a label. */
@Composable
fun SoftBtn(label: String, icon: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val v = LocalVT.current
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier
            .clip(shape)
            .background(v.surf)
            .border(1.dp, v.line, shape)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ico(icon, v.a, 18.dp)
        Spacer(Modifier.width(6.dp))
        Text(label, color = v.fg, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Soft frosted-glass card: translucent fill, light edge, natural shadow. */
@Composable
fun Modifier.glass(r: Dp = 26.dp, elev: Dp = 10.dp): Modifier {
    val v = LocalVT.current
    val s = RoundedCornerShape(r)
    return this
        .shadow(elev, s, ambientColor = Color.Black, spotColor = v.a.copy(alpha = 0.45f))
        .clip(s)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.035f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.04f), v.a.copy(alpha = 0.28f))),
            s
        )
}
